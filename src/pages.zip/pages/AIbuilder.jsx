import React, { useState, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { uploadResumeFile } from '../utils/api'; // Mocked API call

// Assume an AuthContext and StateContext for global state/session management
// For simplicity, we'll use local state and navigate for now.

// Placeholder for the authentication check and page switching
const useAuth = () => {
    // In a real app, this would check a global state/context
    const isAuthenticated = true; // Placeholder
    const navigate = useNavigate();

    if (!isAuthenticated) {
        // Equivalent to st.switch_page("Login.py")
        navigate('/login');
    }
    return isAuthenticated;
}

const AIBuilder = () => {
    const isAuthenticated = useAuth();
    if (!isAuthenticated) return null; // Prevent rendering if not logged in

    const navigate = useNavigate();
    const [modelChoice, setModelChoice] = useState('Llama 3.1');
    const [selectedFile, setSelectedFile] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');
    
    // In a real app, you'd use a global state management solution (Context/Redux)
    // to store the API response, equivalent to st.session_state.api_response
    // For this example, we'll just mock it.
    
    const handleFileChange = (event) => {
        const file = event.target.files[0];
        if (file) {
            setSelectedFile(file);
        }
    };

    const handleFileUpload = async () => {
        if (!selectedFile) {
            setError("Please select a file to upload.");
            return;
        }

        setError('');
        setIsLoading(true);

        try {
            // This is where you would call your new backend API
            const apiResponse = await uploadResumeFile(selectedFile, modelChoice);

            // Store the response in a global state/context (mocked here)
            // st.session_state.api_response = api_response
            
            if (apiResponse.error) {
                setError(apiResponse.error);
            } else {
                alert("Enhancement successful! Redirecting to the editor..."); // Use a toast/notification in a real app
                // Equivalent to st.switch_page("pages/3_📄_Resume_Editor.py")
                navigate('/editor'); 
            }
        } catch (err) {
            setError("An unexpected error occurred during the enhancement process.");
        } finally {
            setIsLoading(false);
        }
    };

    const handleBrowseTemplates = () => {
        // Equivalent to st.switch_page("pages/1_🖼️_Template_Selection.py")
        navigate('/templates');
    }

    return (
        <div style={{ padding: '20px' }}>
            <h1>⚡ AI-Powered Resume Builder</h1>
            <p>Upload your existing resume and let AI enhance its content.</p>

            {/* Model selection equivalent to st.selectbox */}
            <div style={{ marginBottom: '20px' }}>
                <label htmlFor="model-select">Choose your AI Model</label>
                <select 
                    id="model-select" 
                    value={modelChoice} 
                    onChange={(e) => setModelChoice(e.target.value)}
                    style={{ marginLeft: '10px' }}
                >
                    <option value="Llama 3.1">Llama 3.1</option>
                    <option value="Gemini 1.5">Gemini 1.5</option>
                </select>
            </div>

            {/* File uploader equivalent to st.file_uploader */}
            <div style={{ border: '2px dashed #ccc', padding: '50px', textAlign: 'center' }}>
                <input 
                    type="file" 
                    onChange={handleFileChange} 
                    accept=".pdf,.docx,.txt"
                    style={{ display: 'none' }} // Hide the default input
                    id="file-upload"
                />
                <label htmlFor="file-upload" style={{ cursor: 'pointer', display: 'block' }}>
                    Drag and drop your resume here (.pdf, .docx, .txt) or click to browse
                </label>
                {selectedFile && <p>Selected File: <b>{selectedFile.name}</b></p>}
            </div>

            <button 
                onClick={handleFileUpload} 
                disabled={isLoading || !selectedFile}
                style={{ marginTop: '20px', padding: '10px 20px', backgroundColor: '#4CAF50', color: 'white' }}
            >
                {isLoading ? `AI is enhancing your resume using ${modelChoice}...` : 'Enhance Resume'}
            </button>
            
            {error && <p style={{ color: 'red', marginTop: '15px' }}>Error: {error}</p>}
            
            <hr style={{ marginTop: '40px', marginBottom: '20px' }} />
            <p>Prefer to start from scratch or choose a template?</p>
            <button onClick={handleBrowseTemplates} style={{ padding: '10px 20px', backgroundColor: '#007BFF', color: 'white' }}>
                Browse Templates
            </button>
        </div>
    );
}

export default AIBuilder;