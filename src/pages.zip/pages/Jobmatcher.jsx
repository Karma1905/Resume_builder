import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { analyzeMatch, generateCoverLetter } from '../utils/api'; // Mocked API calls
import { getResumeTextFromState } from '../utils/resumeUtils'; // Local utility

// Mocked helper function for resume data manipulation
// In a real React app, `editor_form_data` would likely be from a global state/context
// File: src/utils/resumeUtils.js
export const getResumeTextFromState = () => {
    // This function needs to access the global state where your editor data is stored.
    // For this example, we will return a placeholder text.
    // In a real application, you'd use a Context Hook to pull 'editor_form_data'.
    const editorData = JSON.parse(localStorage.getItem('mock_editor_form_data') || 'null');

    if (editorData) {
        // The logic to format the JSON data back to text as in the Python file
        const lines = [];
        lines.push(editorData.name || '');
        // ... (rest of the conversion logic from the Python file) ...
        return "Resume data from editor: " + editorData.name + "...\n" + editorData.summary;
    }
    return ""; // Empty string if no data is found
};


const JobMatcher = () => {
    const navigate = useNavigate();
    // --- AUTHENTICATION CHECK ---
    // if (!st.session_state.get('logged_in', False)): navigate("/login");
    const isAuthenticated = true; // Placeholder for a global auth check

    useEffect(() => {
        if (!isAuthenticated) navigate('/login');
    }, [isAuthenticated, navigate]);

    // Pre-fill the resume text from global state (mocked utility)
    const initialResumeText = getResumeTextFromState();

    const [resumeText, setResumeText] = useState(initialResumeText);
    const [jdText, setJdText] = useState('');
    const [analysisResult, setAnalysisResult] = useState(null);
    const [coverLetter, setCoverLetter] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
    const [isLoadingCoverLetter, setIsLoadingCoverLetter] = useState(false);
    const [error, setError] = useState('');
    
    // Equivalent to the Python function to clear cover letter state
    const clearPreviousResults = () => {
        setCoverLetter(null); 
    };

    const handleAnalyzeMatch = async () => {
        clearPreviousResults();
        if (!resumeText.trim() || !jdText.trim()) {
            setError("Please paste both your resume and the job description.");
            return;
        }

        setError('');
        setIsLoading(true);
        setAnalysisResult(null);

        try {
            // Call the new backend API for matching
            const result = await analyzeMatch(resumeText, jdText); 
            setAnalysisResult(result);
            if (result.error) {
                setError(result.error);
            }
        } catch (err) {
            setError("An error occurred during AI analysis.");
        } finally {
            setIsLoading(false);
        }
    };

    const handleGenerateCoverLetter = async () => {
        setIsLoadingCoverLetter(true);
        setError('');
        
        // Mocking user name retrieval from global state
        const userName = localStorage.getItem('username') || 'Guest';

        try {
            // Call the new backend API to generate the cover letter
            const letter = await generateCoverLetter(resumeText, jdText, userName);
            setCoverLetter(letter);
        } catch (err) {
            setError("An error occurred while generating the cover letter.");
        } finally {
            setIsLoadingCoverLetter(false);
        }
    };

    return (
        <div style={{ padding: '20px' }}>
            <h1>🤖 AI Job Matcher</h1>
            <p>Paste your resume and a job description below to see how well you match!</p>

            <div style={{ display: 'flex', gap: '30px' }}>
                {/* Equivalent to col1 */}
                <div style={{ flex: 1 }}>
                    <h3>Your Resume</h3>
                    <textarea
                        value={resumeText}
                        onChange={(e) => setResumeText(e.target.value)}
                        placeholder="Paste your resume content here"
                        style={{ width: '100%', height: '400px', padding: '10px' }}
                    />
                </div>
                {/* Equivalent to col2 */}
                <div style={{ flex: 1 }}>
                    <h3>Job Description</h3>
                    <textarea
                        value={jdText}
                        onChange={(e) => setJdText(e.target.value)}
                        placeholder="Paste the job description here"
                        style={{ width: '100%', height: '400px', padding: '10px' }}
                    />
                </div>
            </div>

            <button
                onClick={handleAnalyzeMatch}
                disabled={isLoading}
                style={{ width: '100%', padding: '15px', marginTop: '20px', backgroundColor: '#007BFF', color: 'white', border: 'none', cursor: 'pointer' }}
            >
                {isLoading ? "AI is analyzing the match..." : "Analyze Match"}
            </button>
            
            {error && <p style={{ color: 'red', marginTop: '15px' }}>Error: {error}</p>}

            {/* --- DISPLAY RESULTS --- */}
            {analysisResult && (
                <div style={{ marginTop: '40px', borderTop: '1px solid #ccc', paddingTop: '20px' }}>
                    <h2>Analysis Results</h2>
                    
                    {analysisResult.error ? (
                        <p style={{ color: 'red' }}>An error occurred: {analysisResult.error}</p>
                    ) : (
                        <>
                            <p style={{ fontSize: '24px', fontWeight: 'bold' }}>
                                Match Score: <span style={{ color: analysisResult.match_score > 70 ? 'green' : 'orange' }}>{analysisResult.match_score}%</span>
                            </p>
                            
                            <h4>Summary</h4>
                            <p>{analysisResult.summary || 'No summary provided.'}</p>
                            
                            {/* Simple Tab implementation (replace with a proper React tab component) */}
                            <div style={{ marginTop: '20px' }}>
                                <h4>Tailoring & Keywords</h4>
                                
                                <h5>✅ Matching Keywords</h5>
                                <ul>
                                    {(analysisResult.matching_keywords || []).map((keyword, index) => (
                                        <li key={`match-${index}`}><b>{keyword}</b></li>
                                    ))}
                                </ul>

                                <h5>❌ Missing Keywords</h5>
                                <ul>
                                    {(analysisResult.missing_keywords || []).map((keyword, index) => (
                                        <li key={`missing-${index}`}>{keyword}</li>
                                    ))}
                                </ul>
                                
                                <h5>📝 Tailoring Suggestions</h5>
                                <ul>
                                    {(analysisResult.tailoring_suggestions || []).map((suggestion, index) => (
                                        <li key={`suggest-${index}`} style={{ backgroundColor: '#e9f7ff', padding: '5px', margin: '5px 0' }}>{suggestion}</li>
                                    ))}
                                </ul>
                            </div>
                            
                            <hr style={{ marginTop: '20px', marginBottom: '20px' }} />
                            <h3>Next Step: Generate Cover Letter</h3>
                            <button 
                                onClick={handleGenerateCoverLetter} 
                                disabled={isLoadingCoverLetter}
                                style={{ width: '100%', padding: '15px', backgroundColor: '#4CAF50', color: 'white', border: 'none', cursor: 'pointer' }}
                            >
                                {isLoadingCoverLetter ? "AI is writing your cover letter..." : "✍️ Generate AI Cover Letter"}
                            </button>
                        </>
                    )}
                </div>
            )}
            
            {/* Display Cover Letter */}
            {coverLetter && (
                <div style={{ marginTop: '40px', borderTop: '1px solid #ccc', paddingTop: '20px' }}>
                    <h2>Your AI-Generated Cover Letter</h2>
                    <textarea 
                        value={coverLetter} 
                        style={{ width: '100%', height: '500px', padding: '10px' }}
                        readOnly={false} // Allows editing
                    />
                </div>
            )}
        </div>
    );
}

export default JobMatcher;